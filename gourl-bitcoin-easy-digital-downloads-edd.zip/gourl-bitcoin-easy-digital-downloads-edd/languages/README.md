# WARNING! DO NOT PUT CUSTOM TRANSLATIONS HERE!

GoUrl will delete all custom translations placed in this directory.

## Translating GoUrl
Put your custom GoUrl translations in your WordPress language directory, located at: wp-content/languages/plugins/gourl-edd-{$locale}.mo";

## Contributing your translating to GoUrl
If you want to help translate GoUrl, please visit our [translation page](https://gourl.io/languages.html).